//Connect to server
var ws = new WebSocket( "ws://localhost:8888" );
ws.onopen = initConn;
ws.onmessage = onMessage;

function initConn( e ) {
	var msg = [ 'conn', new Player( 96, 480, prompt( 'Enter name.' ) ) ];
	console.log( msg );
	ws.send( JSON.stringify( msg ) );
}

//World Variables
var map = { tw: 64, th: 48 },
	tile = 32,
	meter = tile,
	gravity = meter * 9.8 * 6,
	maxdx = meter * 20,
	maxdy = meter * 60,
	accel = maxdx * 2,
	friction = maxdx * 6,
	jump = meter * 1500,
	fly = gravity;

//Game Variables
var canvas = document.createElement( 'canvas' ),
	ctx = canvas.getContext( '2d' ),
	viewport = document.getElementById( 'gameCanvas' ),
	viewCtx = viewport.getContext( '2d' ),
	width = canvas.width = map.tw * tile,
	height = canvas.height = map.th * tile,
	container = document.getElementById( 'container' ),
	players = {},
	playerID;

viewport.height = height / 4;
viewport.width = width / 4;

container.style.height = height / 4;
container.style.width = width / 4;

function onMessage( e ) {
	//console.log( e.data );
	var msgData = JSON.parse( e.data ),
		action = msgData[0],
		stringPlayers,
		moveParams,
		newPlayer,
		newID;

	//console.log( msgData );
	if( action == 'init' ) {
		playerID = msgData[1];
		stringPlayers = JSON.parse( msgData[2] );
		for( var strNum in stringPlayers ) {
			players[ parseInt( strNum ) ] = stringPlayers[ strNum ];
		}
	} else if( action == 'blaster' ) {
		players[msgData[1]][action] = msgData[2];
	} else if( action == 'move' ) {
		players[msgData[1]][msgData[2]] = true;
		if( msgData[2] == 'jump' ) {
			players[msgData[1]]['spaceCount'] += 1;
		}
	} else if( action == 'stop' ) {
		players[msgData[1]][msgData[2]] = false;
		if( msgData[2] == 'jump' ) {
			players[msgData[1]]['flying'] = false;
		}
	} else if( action == 'conn' ) {
		newID = msgData[1];
		newPlayer = msgData[2];
		players[newID] = newPlayer;
	} else if( action == 'dc' ) {
		delete players[ msgData[1] ];
	}
}

function Player( x, y, handle ){ 
	this.handle = handle;
	this.x = x; //32
	this.y = y; //1472
	this.blaster = 0;
	//this.canFly = false;
	this.flying = false;
	this.spaceCount = 0;
	this.dx = 0;
	this.dy = 0;
}

function tile2pix( t ) {
	return t * tile;
}

function pix2tile( p ) {
	return Math.floor( p / tile );
}

var color  = { 
		black: '#000000', 
		yellow: '#ECD078', 
		brick: '#D95B43', 
		pink: '#C02942', 
		purple: '#542437', 
		grey: '#333', 
		slate: '#53777A' 
	},
    colors = [ 
		color.black, 
		color.yellow, 
		color.brick, 
		color.pink, 
		color.purple, 
		color.grey 
	];

var cells = [5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 4, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 3, 3, 3, 3, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 5, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 2, 2, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 2, 2, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 2, 2, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 5, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 2, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 0, 0, 0, 0, 0, 5, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 5, 5, 2, 2, 2, 5, 5, 5, 5, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 0, 0, 0, 5, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 2, 2, 2, 5, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 5, 5, 5, 5, 5, 5, 5, 5, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 5, 5, 5, 5, 5, 5, 5, 0, 0, 0, 0, 0, 0, 0, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 5, 5, 5, 5, 5, 5, 5, 5, 5, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2];

function tcell( tx, ty ) {
	return cells[ tx + ( ty * map.tw ) ];
}

function timestamp() {
	if( window.performance && window.performance.now ) {
		return window.performance.now();
	} else {
		return new Date().getTime();
	}
}

 function bound(x, min, max) {
	return Math.max(min, Math.min(max, x));
}

var fps = 60,
	step = 1 / fps,
	dt = 0,
	now, last = timestamp();

function frame() {
	now = timestamp();
	dt = dt + Math.min( 1, ( now - last ) / 1000 );
	render( ctx, viewCtx );
	last = now;
	requestAnimationFrame( frame, canvas );
}
frame();
setInterval( function() {
	for( var id in players ) {
		update( step, players[id] );
	}
}, 1000 / fps );

//Check for keyDown before send() to WS
isKeyDown = {
	left: false,
	right: false,
	space: false
}

function keyPress( e ) {
	var moveParams = [ 'move' ];
	if( e.keyCode == 65 || e.keyCode == 37 ) { //a OR left
		if( !isKeyDown.left ) {
			moveParams.push( 'left' );
			isKeyDown.left = true;
		}
	} else if( e.keyCode == 68 || e.keyCode == 39 ) { //d OR right
		if( !isKeyDown.right ) {
			moveParams.push( 'right' );
			isKeyDown.right = true;
		}
	} else if( e.keyCode == 32 ) { //space
		if( !isKeyDown.space ) {
			moveParams.push( 'jump' );
			isKeyDown.space = true;
		}
	}
	if( moveParams[1] ) {
		ws.send( JSON.stringify( moveParams ) );
	}
}

function keyRelease( e ) {
	var moveParams = [ 'stop' ];
	if( e.keyCode == 65 || e.keyCode == 37 ) { //a OR left
		moveParams.push( 'left' );
		isKeyDown.left = false;
	} else if( e.keyCode == 68 || e.keyCode == 39 ) { //d OR right
		moveParams.push( 'right' );
		isKeyDown.right = false;
	} else if( e.keyCode == 32 ) { //space
		moveParams.push( 'jump' );
		isKeyDown.space = false;
	}
	if( moveParams[1] ) {
		ws.send( JSON.stringify( moveParams ) );
	}
}

function mouseMove( e ) {
	if( playerID ) {
		var posX, posY, atanX, atanY, atanMsg;
		if( e.offsetX ) {
			posX = e.offsetX;
			posY = e.offsetY;
		} else if( e.layerX ) {
			posX = e.layerX;
			posY = e.layerY;
		}
		atanX = ( viewport.width / 2 ) - posX;
		atanY = ( viewport.height / 2 ) - posY;
		atanMsg = Math.atan2( atanY, atanX );
		console.log( ( atanMsg / Math.PI ) * 180 );
		ws.send( JSON.stringify( [ 'blaster', atanMsg ] ) );
	}
}

document.addEventListener( 'keydown', keyPress, false );
document.addEventListener( 'keyup', keyRelease, false );
viewport.addEventListener( 'mousemove', mouseMove, false );

function update( dt, player ) {
	var wasLeft = player.dx < 0,
		wasRight = player.dx > 0,
		falling = player.falling;

	player.ddx = 0;
	player.ddy = gravity;

	if( player.left ) {
		player.ddx -= accel;
	} else if( wasLeft ) {
		player.ddx += friction;
	}

	if( player.right ) {
		player.ddx += accel;
	} else if( wasRight ) {
		player.ddx -= friction;
	}

	if( player.jump ) {
		if( !player.jumping && !player.falling && player.spaceCount == 1 ) {
			player.ddy -= jump;
			player.jumping = true;
		} else if ( player.spaceCount > 1 && !player.flying ) {
			console.log( player );
			console.log( 'Init jump' );
			player.dy = fly * dt + ( ( fly * dt ) );
			player.ddy -= fly;
			player.flying = true;
		} else if ( player.flying ) {
			player.ddy = -fly;
		}
	}

	player.x = Math.floor( player.x + ( dt * player.dx ) );
	player.y = Math.floor( player.y + ( dt * player.dy ) );
	player.dx = bound( player.dx + ( dt * player.ddx ), -maxdx, maxdx );
	player.dy = bound( player.dy + ( dt * player.ddy ), -maxdy, maxdy );

	if( ( wasLeft && ( player.dx > 0 ) ) || ( wasRight && ( player.dx < 0 ) ) ) {
		player.dx = 0;
	}

	var tx = pix2tile( player.x ),
		ty = pix2tile( player.y ),
		nx = player.x % tile,
		ny = player.y % tile,
		cell = tcell( tx, ty ),
		cellRight = tcell( tx + 1, ty ),
		cellDown = tcell( tx, ty + 1 ),
		cellDiag = tcell( tx + 1, ty + 1 );

	if( player.dy > 0 ) {
		if( ( cellDown && !cell ) || ( cellDiag && !cellRight && nx ) ) {
			player.y = tile2pix( ty );
			player.dy = 0;
			player.falling = false;
			player.jumping = false;
			player.flying = false;
			player.spaceCount = 0;
			ny = 0;
		}
	} else if( player.dy < 0 ) {
		if( ( cell && !cellDown ) || ( cellRight && !cellDiag && nx ) ) {
			player.y = tile2pix( ty + 1 );
			player.dy = 0;
			cell = cellDown;
			cellRight = cellDiag;
			ny = 0;
		}
	}

	if ( player.dx > 0 ) {
		if( ( cellRight && !cell ) || ( cellDiag && !cellDown && ny ) ) {
			player.x = tile2pix( tx );
			player.dx = 0;
		} 
	} else if( player.dx < 0 ) {
		if( ( cell && !cellRight ) || ( cellDown && !cellDiag && ny ) ) {
			player.x = tile2pix( tx + 1 );
			player.dx = 0;
		}
	}

	player.falling = ! ( cellDown || ( nx && cellDiag ) );
	ws.send( JSON.stringify( [ 'update', player ] ) );
}

function render( ctx, viewCtx ) {
	var colorSub = 0,
		x, 
		y;
	for( y = 0; y < map.th; y++ ) {
		for( x = 0; x < map.tw; x++ ) {
			colorSub = 0
			if( tcell( x, y ) != 0 ) {
				colorSub = 1;
			}
			ctx.fillStyle = colors[ tcell( x, y ) - colorSub ];
			ctx.fillRect( x * tile, y * tile, tile, tile );
		}
	}

	for( var id in players ) {
		ctx.font = "20px Arial";
		ctx.fillText( players[id].handle, players[id].x + ( tile / 2 ) - ( ctx.measureText( players[id].handle ).width / 2 ), players[id].y - ( 10 ) );

		ctx.fillStyle = color.yellow;
		ctx.fillRect( players[id].x, players[id].y, tile, tile );

		ctx.save();
		ctx.translate( players[id].x + ( tile / 2 ), players[id].y + ( tile / 2 ) );
		ctx.rotate( players[id].blaster );
		//console.log( players[id].blaster );
		ctx.translate( -(players[id].x + ( tile / 2 )), -(players[id].y + ( tile / 2 )) );
		ctx.fillStyle = color.slate;
		ctx.fillRect( players[id].x, players[id].y, tile, tile );
		ctx.restore();
	}

	if( playerID ) {
		viewCtx.setTransform( 1, 0, 0, 1, 0, 0, 1, 0, 0 );
		viewCtx.clearRect( 0, 0, viewport.width, viewport.height );
		viewCtx.translate( -( players[playerID].x - ( viewport.width / 2 ) ), -( players[playerID].y - ( viewport.height / 2 ) ) );
		//viewCtx.translate( 0, -1536 + viewport.height );
		viewCtx.drawImage( canvas, 0, 0 );
		//viewCtx.translate( 32, 1472 );
		//viewCtx.restore();
	}
}
//viewport.webkitRequestFullScreen();